package com.vaskka.web.iicamp.utils;

import com.google.gson.Gson;
import com.vaskka.web.iicamp.handler.GetUnregisterUser;
import com.vaskka.web.iicamp.handler.VerifyCode;
import com.vaskka.web.iicamp.request.GetUnregisterUserRequestInner;
import com.vaskka.web.iicamp.request.LoginRequest;
import com.vaskka.web.iicamp.request.VerifyCodeRequest;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @program: FT
 * @description: Util 常用类
 * @author: Vaskka
 * @create: 2018/11/21 6:35 PM
 **/

public class Util {


    /**
     * 读取body
     * @param request HttpServletRequest
     * @return String
     */
    public static String getRequestBody(HttpServletRequest request) {
        try (BufferedReader reader = request.getReader()) {
            StringBuilder stringBuilder = new StringBuilder();

            String s;
            while ((s = reader.readLine()) != null) {
                stringBuilder.append(s);
            }

            return stringBuilder.toString();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;


    }


    /**
     * 输出网络请求
     * @param response HttpServletResponse
     * @param content String
     * @throws IOException IOException
     */
    public static void httpOutput(HttpServletResponse response, String content) throws IOException {
        response.setContentType("application/json");
        response.getWriter().println(content);
    }


    /**
     * 获得Request GetUnregisterUserRequestInner
     * @param request HttpServletRequest
     * @return GetUnregisterUserRequestInner
     */
    public static GetUnregisterUserRequestInner getUnregisterUserRequestInner(HttpServletRequest request) {
        String body = getRequestBody(request);

        GetUnregisterUserRequestInner u = (new Gson().fromJson(body, GetUnregisterUserRequestInner.class));

        return u;
    }


    /**
     * 用户雁阵验证码
     * @param request HttpServletRequest
     * @return VerifyCodeRequest
     */
    public static VerifyCodeRequest getVerifyCodeRequest(HttpServletRequest request) {
        String body = getRequestBody(request);

        VerifyCodeRequest re = (new Gson()).fromJson(body, VerifyCodeRequest.class);

        return re;
    }


    /**
     * 用户登陆请求
     * @param request
     * @return
     */
    public static LoginRequest getLoginRequest(HttpServletRequest request) {
        String body = getRequestBody(request);

        LoginRequest re = (new Gson()).fromJson(body, LoginRequest.class);

        return re;
    }


    /**
     * 随机数
     * @return 当前时间String yyyy-MM-dd HH:mm:ss
     */
    public static String getNowTime() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        return (df.format(new Date()));// new Date()为获取当前系统时间
    }

    /**
     * 获得随机数
     * @return
     */
    public static String getRandInt() {
        java.util.Random r=new java.util.Random(System.currentTimeMillis());

        return String.valueOf(r.nextInt());
    }


    /**
     * 获得随机id
     * @param name 名字
     * @return String
     */
    public static String getRandomId(String name) {

        StringBuilder sb = new StringBuilder();

        sb.append(name);
        sb.append("-");

        int f = name.length() + 1;

        String s = MD5Utils.MD5Encode("asd", null);

        sb.append(s);

        return sb.toString().substring(0, 32);
    }

}
